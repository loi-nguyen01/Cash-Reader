# raspicash
code for raspberry pi cash register


To create this project there are several steps you need to complete:

Setting up the Raspberry Pi

  1. Installing raspbian
  
  2. Connecting camera module

  3. Install opencv: installOpenCV

   

Code

  1. Take library photos for the set: libraryimagecapture
  2. Write Python code to run Akaze or use OpenAI(*API key needed*): comp || OpenAI
  3. Add a button and LED





Build Case for testing and later final


![IMG_9946](https://github.com/kianteymouri/raspicash/assets/96223486/45181bdb-3ddf-40f8-a370-56ccd2923e0d)


Final Test and Modify

![IMG_9966](https://github.com/kianteymouri/raspicash/assets/96223486/63560f3c-58ce-4f24-ac55-4ae8688974c7)


Use contrib to run on boot
  - open terminal, type:
  - python3 /home/pi/Desktop/comp.py
  - sudo crontab -e
  - drop down to bottom of file and type: @reboot python3 /home/pi/Desktop/comp.py &
  - cntrl s(save) and cntrl x(exit)


Youtube video with explanation: 

